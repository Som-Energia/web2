<?php
/**
 * Plugin Name: Apollo13 Shortcodes
 * Description: Shortcodes for Apollo13 Themes with support for Visual Composer plugin.
 * Version: 1.0.7
 * Author: Apollo13
 * Author URI: http://apollo13.eu/
 * License: GPL2
 */

//we don't use it anymore
return;


